﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestCalculator
{
    public partial class PokeCalc : Form
    {
        public PokeCalc()
        {
            InitializeComponent();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("Pocket Calculator in C# by Aleksander Barczak (c)2024","About",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void PokeCalc_Load(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_multiply_Click(object sender, EventArgs e)
        {
            String text = (sender as Button).Text;
            txt_calc.Text = txt_calc.Text + text;
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_calc.Text = "";
        }

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            DataTable table = new DataTable();

            string result;
            result = table.Compute(txt_calc.Text, null).ToString();

            txt_calc.Text = result;
        }
    }
}
